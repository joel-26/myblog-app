import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  blogs: [],
  filter: '',
  sort: 'none',
};

const blogSlice = createSlice({
  name: 'blogs',
  initialState,
  reducers: {
    addBlog: (state, action) => {
      state.blogs.push(action.payload);
    },
    editBlog: (state, action) => {
      const index = state.blogs.findIndex(blog => blog.id === action.payload.id);
      if (index >= 0) {
        state.blogs[index] = action.payload.updatedBlog;
      }
    },
    deleteBlog: (state, action) => {
      state.blogs = state.blogs.filter(blog => blog.id !== action.payload);
    },
    addComment: (state, action) => {
      const blog = state.blogs.find(blog => blog.id === action.payload.blogId);
      if (blog) {
        blog.comments.push(action.payload.comment);
      }
    },
    setFilter: (state, action) => {
      state.filter = action.payload;
    },
    setSort: (state, action) => {
      state.sort = action.payload;
    },
  },
});

export const { addBlog, editBlog, deleteBlog, addComment, setFilter, setSort } = blogSlice.actions;
export default blogSlice.reducer;

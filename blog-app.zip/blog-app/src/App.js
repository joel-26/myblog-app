import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import BlogList from './pages/BlogList';
import BlogForm from './pages/BlogForm';
import BlogDetails from './pages/BlogDetails';
import LoginPage from './pages/LoginPage';

function App() {
  return (
    <Router>
             <Navbar />
      <Routes>
        <Route path="/login" element={<LoginPage />}/>
        <Route path="/blogs" element={<BlogList />} />
        <Route path="/blogs/add" element={<BlogForm />} />
        <Route path="/blogs/edit/:id" element={<BlogForm />} />
        <Route path="/blogs/:id" element={<BlogDetails />} />
      </Routes>
    </Router>
  );
}

export default App;

import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addBlog, editBlog } from '../redux/blogSlice';
import { useNavigate, useParams } from 'react-router-dom';

const BlogForm = () => {
  const { id } = useParams();
  const blogs = useSelector((state) => state.blogs.blogs);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    thumbnail: null,
    trailer: null,
  });

  useEffect(() => {
    if (id) {
      const blogToEdit = blogs.find((blog) => blog.id === id);
      if (blogToEdit) setFormData(blogToEdit);
    }
  }, [id, blogs]);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setFormData({
      ...formData,
      [name]: files ? files[0] : value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (id) {
      dispatch(editBlog({ id, updatedBlog: formData }));
    } else {
      dispatch(addBlog({ ...formData, id: Date.now().toString() }));
    }
    navigate('/blogs');
  };

  return (
    <div style={styles.container}>
      <h2>{id ? 'Edit Blog' : 'Add Blog'}</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
       <div style={styles.flex}> 
        <p>Enter Blog name:</p>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="Blog Name"
          style={styles.input}
          required
        /></div>

        <div style={styles.flex}>
          <p>Enter Blog description:</p> 
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="Blog Description"
          style={styles.textarea}
          required
        ></textarea>
        </div>

          <div style={styles.flex}>
        <p>Upload Thumbnail:</p>
        <input
          type="file"
          name="thumbnail"
          accept="image/*"
          onChange={handleChange}
          style={styles.input}
          required
        />
        </div>
            
            <div style={styles.flex}>
         <p>Upload Trailer:</p>
        <input
          type="file"
          name="trailer"
          accept="video/*"
          onChange={handleChange}
          style={styles.input}
          required
        />
        </div>
        <button type="submit" style={styles.button}>{id ? 'Update Blog' : 'Create Blog'}</button> &nbsp;&nbsp;&nbsp;
        <button type="button" style={styles.button} onClick={()=> navigate('/blogs')}>Cancel</button>
      </form>
    </div>
  );
};

const styles = {
  container: { padding: '20px' },
  form: { maxWidth: '500px', margin: 'auto' },
  input: { display: 'block', margin: '10px 0', padding: '10px', width: '100%' },
  textarea: { display: 'block', margin: '10px 0', padding: '10px', width: '100%', height: '100px' },
  button: { padding: '10px 20px', background: '#007BFF', color: 'white', border: 'none', borderRadius: '5px' },
  flex:{ display:"flex" }
};

export default BlogForm;

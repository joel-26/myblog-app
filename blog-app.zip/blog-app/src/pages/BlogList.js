import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { setFilter, setSort } from '../redux/blogSlice'; 
import './styles.css'
import BlogCard from '../components/BlogCard';
import { Button } from 'antd';

const BlogList = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const blogs = useSelector((state) => state.blogs.blogs);
  const filter = useSelector((state) => state.blogs.filter);
  const sort = useSelector((state) => state.blogs.sort);

  const [searchTerm, setSearchTerm] = useState('');

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
    dispatch(setFilter(event.target.value)); 
  };

  const handleSortChange = (event) => {
    const sortValue = event.target.value;
    dispatch(setSort(sortValue)); 
  };

  const filteredBlogs = blogs.filter((blog) => {
    return (
      blog.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      blog.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const sortedBlogs = filteredBlogs.sort((a, b) => {
    if (sort === 'asc') {
      return a.name.localeCompare(b.name); 
    } else if (sort === 'desc') {
      return b.name.localeCompare(a.name); 
    } else {
      return 0; 
    }
  });

  return (
    <div>
      <h1>Blog List</h1>
<Button type='primary' style={{float:"right"}} onClick={()=> navigate('/blogs/add')}>Create a Blog</Button>
<div className='filterBar'>
        <input
          type="text"
          placeholder="Search blogs by name or description"
          className='search-input'
          value={searchTerm}
          onChange={handleSearchChange}
        />
         <div >
        <select onChange={handleSortChange} value={sort} className='sort-select'>
          <option value="asc">Sort by Name</option>
          <option value="desc">Sort by Date</option>
        </select>
      </div>
      </div>

      <div >
        {sortedBlogs.map((blog) => (
          <div>
          <BlogCard blog={blog} />
          </div> 
        ))}
      </div>
        {sortedBlogs.length <= 0 ? <Button type='primary' onClick={()=> navigate('/blogs/add')}>Add Blog</Button> : null}
    </div>
  );
};

export default BlogList;

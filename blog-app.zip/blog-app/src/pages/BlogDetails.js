import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useParams } from 'react-router-dom';
import { addComment } from '../redux/blogSlice';

const BlogDetails = () => {
  const { id } = useParams();
  const blog = useSelector((state) => state.blogs.blogs.find((b) => b.id === id));
  const dispatch = useDispatch();
  const [comment, setComment] = useState('');

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    dispatch(addComment({ blogId: id, comment }));
    setComment('');
  };

  if (!blog) return <p>Blog not found</p>;

  return (
    <div style={styles.container}>
      <h2>{blog.name}</h2>
      <p>{blog.description}</p>
      <img src={URL.createObjectURL(blog.thumbnail)} alt="Thumbnail" style={styles.image} />
      <video src={URL.createObjectURL(blog.trailer)} controls style={styles.video}></video>
      <h3>Comments</h3>
      {blog.comments?.map((c, index) => (
        <p key={index}>&bull; {c}</p>
      ))}
      <form onSubmit={handleCommentSubmit} style={styles.form}>
        <input
          type="text"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Add a comment"
          style={styles.input}
          required
        />
        <button type="submit" style={styles.button}>Add Comment</button>
      </form>
    </div>
  );
};

const styles = {
  container: { padding: '20px' },
  image: { maxWidth: '100%', marginBottom: '20px' },
  video: { maxWidth: '100%', marginBottom: '20px' },
  form: { marginTop: '20px' },
  input: { padding: '10px', width: '100%', marginBottom: '10px' },
  button: { padding: '10px 20px', background: '#007BFF', color: 'white', border: 'none', borderRadius: '5px' },
};

export default BlogDetails;

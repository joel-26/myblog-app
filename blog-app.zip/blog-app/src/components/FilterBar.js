import React, { useState } from 'react';

const FilterBar = ({ onFilterChange, onSortChange }) => {
  const [filterText, setFilterText] = useState('');
  const [sortOption, setSortOption] = useState('');

  const handleFilterChange = (e) => {
    setFilterText(e.target.value);
    onFilterChange(e.target.value);
  };

  const handleSortChange = (e) => {
    setSortOption(e.target.value);
    onSortChange(e.target.value);
  };

  return (
    <div style={styles.filterBar}>
      <input
        type="text"
        placeholder="Filter by name or description"
        value={filterText}
        onChange={handleFilterChange}
        style={styles.input}
      />
      <select value={sortOption} onChange={handleSortChange} style={styles.select}>
        <option value="">Sort By</option>
        <option value="name">Name</option>
        <option value="description">Description</option>
      </select>
    </div>
  );
};

const styles = {
  filterBar: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '16px',
    padding: '0 16px',
  },
  input: {
    padding: '8px',
    width: '60%',
    border: '1px solid #ccc',
    borderRadius: '4px',
  },
  select: {
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    background: 'white',
  },
};

export default FilterBar;

import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { logout } from '../redux/authSlice';
import { IoMdAddCircleOutline } from 'react-icons/io';
import { FaListUl } from 'react-icons/fa';

const Navbar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch(logout());
    navigate('/');
  };

  return (
    <nav style={styles.navbar}>
      
      <button onClick={handleLogout} style={styles.button}>Logout</button>
    </nav>
  );
};

const styles = {
  navbar: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '6px',
    background: '#242625',
    color: 'white',
  },
  link: {
    textDecoration: 'none',
    color: 'white',
    fontWeight: 'bold',
    margin: '0 16px',
  },
  button: {
    padding: '8px 16px',
    border: 'none',
    background: 'white',
    color: '#007BFF',
    borderRadius: '4px',
    cursor: 'pointer',
  },
};

export default Navbar;

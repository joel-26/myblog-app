import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { deleteBlog } from '../redux/blogSlice';
import { Link, useNavigate } from 'react-router-dom';
import { Button, Modal } from 'antd';



const BlogCard = ({ blog }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [modalOpen, setModalOpen] = useState(false);

  const handleEdit = () => {
    navigate(`/blogs/edit/${blog.id}`);
  };

  const handleDelete = () => {
          setModalOpen(true);
  };

  return (
    <div style={styles.card}>
      <img 
        src={URL.createObjectURL(blog.thumbnail)} 
        alt="Thumbnail" 
        style={styles.image} 
      />
      <h3>{blog.name}</h3>
      <p>{blog.description}</p>
      <Link to={`/blogs/${blog.id}`}>View Details</Link>
      <div style={styles.actions}>
        <button onClick={handleEdit} style={styles.button}>Edit</button>
        <button onClick={handleDelete} style={styles.button}>Delete</button>
      </div>
      <div>
      <Modal
      visible={modalOpen}
      footer={false}
      onCancel={()=> setModalOpen(false)}
      >
        
        
          <div>
            <p>Are you sure you want to delete this blog?</p>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <Button onClick={() => dispatch(deleteBlog(blog.id))} type='primary' danger>Delete</Button>
            </div>
          </div>
      </Modal>
      </div>
    </div>
  );
};

const styles = {
  card: {
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '16px',
    margin: '16px',
    textAlign: 'center',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    width:'20%',
  },
  image: {
    width: '100%',
    height: '150px',
    objectFit: 'cover',
    borderRadius: '8px',
  },
  actions: {
    display: 'flex',
    justifyContent: 'space-around',
    marginTop: '12px',
  },
  button: {
    padding: '8px 16px',
    border: 'none',
    background: '#007BFF',
    color: 'white',
    borderRadius: '4px',
    cursor: 'pointer',
  },
};

export default BlogCard;
